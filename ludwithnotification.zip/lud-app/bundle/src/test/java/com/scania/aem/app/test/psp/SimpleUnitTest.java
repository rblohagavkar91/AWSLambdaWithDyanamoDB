package com.scania.aem.app.test.psp;

import static org.junit.Assert.*;

import org.junit.Test;

public class SimpleUnitTest {

    @Test
    public void someTest() {
        assertTrue(true);
    }

}