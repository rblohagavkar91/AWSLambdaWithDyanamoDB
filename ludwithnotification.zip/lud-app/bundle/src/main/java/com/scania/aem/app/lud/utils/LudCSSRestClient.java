package com.scania.aem.app.lud.utils;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.util.Map;
import java.util.TreeMap;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class LudCSSRestClient {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LudCSSRestClient.class);
	
	// AUTHENTICATION TOKEN
    private static final String AUTHENTICATION_DOMAIN = "statistics.reflex.prod.aws.scania.com";
    private static final String VERSION = "v0";
    private static final String AUTHENTICATION_URL = String.format("https://%s/%s/authentication", AUTHENTICATION_DOMAIN, VERSION);
    private static TreeMap<String, String> authenticationToken;

    // SEARCH REQUEST
    private static final String SEARCH_DOMAIN = "search.reflex.prod.aws.scania.com";
    private static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
    private static final String REGION_NAME = "eu-west-1";
    private static final String SERVICE_NAME = "execute-api";
    private static final String AUTH_URL = "https://statistics.reflex.prod.aws.scania.com/v0/authentication";
    private static final String uName = "cssstats";
    private static final String pword = "MzE4MzYzZWJkNjJkZTE5MDg4MWNlNTJl";
//    String uName = "";
//    String pword = "MzE4MzYzZWJkNjJkZTE5MDg4MWNlNTJl";

    private static AWSV4Auth awsAuth;
    
	public String getLatestDocuments(String queryString,TreeMap<String, String> queryParameters, String baseUrl,String canonicalURI)
	{
		/* TODO First, check if token is not present, or will expire in five minutes. In that case - renew it.
        if (newTokenNeeded())
            authenticationToken = getAuthenticationToken(); */
    	String completeResponse=null; 
    	String queryUrl = baseUrl+queryString;
    	LOGGER.info("queryUrl:::::::"+queryUrl);
        queryUrl = queryUrl.replaceAll(" ","%20");
        try {
        	String credResponse = getCredentials();
        	LOGGER.info("credentials for second call in getLatestDocuments: "+credResponse);
            JSONObject jsonObject;
            String accessKeyID = null;
            String secretAccessKey = null;
            String sessionToken = null;
            String region = null;
            String expiration = null;
			try {
				  jsonObject = new JSONObject(credResponse);
				  accessKeyID = jsonObject.getString("AccessKeyId");
		          secretAccessKey = jsonObject.getString("SecretAccessKey");
		          sessionToken = jsonObject.getString("SessionToken");
		          region = jsonObject.getString("Region");
		          expiration = jsonObject.getString("Expiration");
		          LOGGER.info("accessKeyID : "+accessKeyID);
		          LOGGER.info("secretAccessKey : "+secretAccessKey);
		          LOGGER.info("sessionToken : "+sessionToken);
		          LOGGER.info("region : "+region);
		          LOGGER.info("expiration : "+expiration);
		          
			} catch (JSONException e) {
				LOGGER.info("JSONException error...");
			}
            String httpMethodName = "GET"; // Always GET
            String payload = ""; // Always empty
            TreeMap<String, String> awsHeaders = new TreeMap<String, String>();
            awsHeaders.put("content-type", CONTENT_TYPE);
            awsHeaders.put("host", SEARCH_DOMAIN);
            awsHeaders.put("x-amz-security-token", sessionToken);
            // TODO parse query params from queryUrl and add to queryParameters
            
            LOGGER.info("Before building awsauth : ");
            
            awsAuth = new AWSV4Auth.Builder(accessKeyID, secretAccessKey)
                                    .regionName(REGION_NAME)
                                    .serviceName(SERVICE_NAME)
                                    .httpMethodName(httpMethodName)
                                    .canonicalURI(canonicalURI)
                                    .queryParameters(queryParameters)
                                    .awsHeaders(awsHeaders)
                                    .payload(payload)
                                    .build();
            
            
            LOGGER.info("after building awsauth ");
            LOGGER.info("after building awsauth : "+awsAuth);
            
            Map<String, String> awsSigningHeaders = awsAuth.getHeaders();
            // If you're on the scania network you need to add proxy (if on server use server proxy)
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("PROXYSESO.SCANIA.COM", 8080));
            URL url = new URL(queryUrl);
            // Workaround for "No subject alternative DNS name matching <hostname>" Java 6 problem
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection(proxy);
            conn.setHostnameVerifier(
                    new javax.net.ssl.HostnameVerifier(){
                        public boolean verify(String hostname,
                                              javax.net.ssl.SSLSession sslSession) {
                            return hostname.equals(SEARCH_DOMAIN);
                        }
                    });
            conn.setRequestMethod("GET");

            for (Map.Entry<String, String> header : awsHeaders.entrySet()) {
                conn.setRequestProperty(header.getKey(), header.getValue());
            }

            for (Map.Entry<String, String> header : awsSigningHeaders.entrySet()) {
                conn.setRequestProperty(header.getKey(), header.getValue());
            }
            
            LOGGER.info("response code from service : "+conn.getResponseCode());
    	 if (conn.getResponseCode() == 200) {
             BufferedReader bufferReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
             String output;
             StringBuilder str = new StringBuilder();
             while ((output = bufferReader.readLine()) != null) {
                      str.append(output);
             }
                 completeResponse = str.toString();
                 LOGGER.info("completeResponse:::::::::::::::: "+completeResponse);
                 bufferReader.close();
                 conn.disconnect();
       }else{
                 LOGGER.info("LUD HTTP error code : "+conn.getResponseCode());
       }
        } catch (IOException e) {
            e.printStackTrace();
        }
       
        return completeResponse;
	}
	
	public static String getCredentials(){
        String completeResponse = new String();
        HttpURLConnection conn = null;
        try {
                  URL url = new URL(AUTH_URL);
                  Proxy p=new Proxy(Proxy.Type.HTTP, new InetSocketAddress("PROXYSESO.SCANIA.COM", 8080));
                  conn = (HttpURLConnection) url.openConnection(p);
                  conn.setRequestMethod("GET");
                  conn.setRequestProperty("Accept", "application/json");
                  String userpass = uName + ":" + pword;
                  String basicAuth = "Basic " + new String(Base64.encodeBase64(userpass.getBytes()));
                  conn.setRequestProperty ("Authorization", basicAuth);
                  if (conn.getResponseCode() == 200) {
                            BufferedReader bufferReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            String output;
                            StringBuilder str = new StringBuilder();
                            while ((output = bufferReader.readLine()) != null) {

                                     str.append(output);
                            }
                            completeResponse = str.toString();
                            LOGGER.info("completeResponse for credentials :"+completeResponse);
                            bufferReader.close();
                            conn.disconnect();
                  }else{
                            LOGGER.info("credentials HTTP error code : "+conn.getResponseCode());
                  }
          } catch (MalformedURLException e) {
                  e.printStackTrace();
          } catch (IOException e) {
                  e.printStackTrace();
          }
        return completeResponse;
}

private static boolean newTokenNeeded() {
return authenticationToken == null || tokenWillExpireWithinFiveMinutes();
}

private static boolean tokenWillExpireWithinFiveMinutes() {
// TODO check if token will expire within 5 minutes
return false;
}

private static void print(InputStream stream) throws IOException {
	ByteArrayOutputStream result = new ByteArrayOutputStream();
	byte[] buffer = new byte[1024];
	int length;
	while ((length = stream.read(buffer)) != -1) {
	 result.write(buffer, 0, length);
	}

	LOGGER.info(result.toString("UTF-8"));
}
}
