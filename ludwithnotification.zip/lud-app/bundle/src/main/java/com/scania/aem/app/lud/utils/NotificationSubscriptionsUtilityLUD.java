package com.scania.aem.app.lud.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.TreeMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NotificationSubscriptionsUtilityLUD {
	private static final Logger LOGGER = LoggerFactory.getLogger(NotificationSubscriptionsUtilityLUD.class);
	private static final String CANONICAL_PRESALES_URI = "/v0/authentication/css/apps/rest/apps/presales-portal/searchers/presales-portal"; // TODO parse from queryUrl
    private static final String PRESALES_SEARCH_URL = "https://search.reflex.prod.aws.scania.com/v0/authentication/css/apps/rest/apps/presales-portal/searchers/presales-portal?";
	
	public String constructPresalesEmailContent() {
        final StringBuffer contentBuilder = new StringBuffer();
        final SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        final Date date = new Date();
        final String todate = formatter.format(date);
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -7);
        final Date todate1 = cal.getTime();
        final String fromDate = formatter.format(todate1);
        final String week = formatter.format(new java.util.Date());
        String hosturl = "https://presales.scania.com/wps/myportal/";
        try {
            String header = "<html xmlns='http://www.w3.org/1999/xhtml' style='background-color:#f5f5f5;'>"
							+"<head>"
							    +"<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>"
							   +" <meta name='viewport' content='width=device-width, initial-scale=1.0'>"
							   +" <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
							+"</head>"
							+"<body style='margin: 0; padding: 0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;'>"
							   +" <table width='100%'>"
							      +"  <table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8; background-color:#fff;'>"
							        +"    <tr>"
							             +"   <td align='left' width='90%' bgcolor='#fff' style='padding: 14px; border-top: 2px solid #ceb888;'>"
							              +"      <h1 style='-moder-bottom-width: 0; color: #666; font-family: 'Open Sans', Arial, sans-serif; font-size: 24px; font-weight: 600; line-height: 1.1; padding-bottom: 0; margin: 15px 0 3px;'>Document news from Presales.scania.com</h1> </td>"
							              +"  <td align='right' width='10%' bgcolor='#fff' style='padding: 14px; border-top: 2px solid #ceb888;'> <img src='https://static.scania.com/resources/logotype/scania/scania-symbol.png' width='36' height='36' style='display: block;'> </td>"
							
							           +" </tr>"
							       +" </table>";
			contentBuilder.append(header);
			
			contentBuilder
			        .append("<table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8; background-color:white;'>"
			                + "<tr>" + "<td align='left' bgcolor='white' style='padding: 20px 20px 20px 14px;'>"
			                + "<span style='font-size:12px; color: #555; font-family: \"Open Sans\",Arial,sans-serif;'>Document news from Scania Presales between period " + fromDate + " and "
			                + todate + "<br>The following documents have been added, <b>moved</b> or updated:</span></td></tr></table>");
			contentBuilder.append(getLatestUpdatedDocuments());
            
			contentBuilder
			        .append("<table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8; background-color:white;'>"
			                + "<tr>" + "<td align='left' bgcolor='white' style='padding: 14px; font-family: \"Open Sans\",Arial,sans-serif; font-size: 12px;'>"
			                + "<p style='color: #555;font-family: \"Open Sans\",Arial,sans-serif;font-size:12px;'>Best regards," + "<br>Presales.scania.com " + "<br>"
			                + "<br>Please note that this e-mail is generated automatically and cannot be replied to." + "<br>" + "<br> If you wish to stop receiving information from <a href='"
			                + hosturl + "'> Presales.scania.com</a>" + "<br> Click <a href='" + hosturl + "'> Edit My subscription</a> and click &quot;Unsubscribe&quot;."
			                + "<br> Log in might be required.</p>" + "</td>" + "</tr>" + "</table>");
			                
			String footer = "<table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse;  border-bottom: 2px solid #ceb888; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8;  background-color:#fff;'>"
			                +"<tr>"
						                +"<td align='left' bgcolor='white' width='30%' style='padding: 0 14px; font-family: Arial, Helvetica, Open Sans, sans-serif; font-size: 10px;'>"
						                   +" <br style='box-sizing: border-box; padding-left: 10px;'> Scania CV AB"
						                    +"<br style='box-sizing: border-box; padding-left: 10px;'> SE-151 87 Södertälje, Sweden"
						                   +" <br style='box-sizing: border-box; padding-left: 10px;'> www.scania.com </td>"
						               +" <td align='center' bgcolor='white' width='40%' style='padding:14px 0; font-family: Arial, Helvetica, Open Sans, sans-serif; font-size: 10px;'>"
						                   +" <br style='box-sizing: border-box;'> Tel: &#43;46-8-55 38 10 00 Fax: &#43;46-8-55 38 10 37 "
						                   +" <br style='box-sizing: border-box;'> Registered in Sweden: No. 556184-8564"
						                   +" <br style='box-sizing: border-box;'> Registered Office: Södertälje, Sweden </td>"
						               +" <td align='right' bgcolor='white' width='30%' style='padding: 0 14px;'> <img src='https://static.scania.com/resources/logotype/scania/scania-wordmark.png' alt='' width='150' height='24' style='border-style: none; float: right;'> </td>"
						           +" </tr>"
						       +" </table>"
						    +"</table>"
						+"</body>"
						+"</html>";
            
			contentBuilder.append(footer);
        } catch (final Exception ex) {
            LOGGER.info("Unable to construct notification email" + ex.toString());
        }
        return contentBuilder.toString();
    }
	
	public String getLatestUpdatedDocuments()
	{
		LOGGER.info("Entered into getLatestUpdatedDocuments of NotificationSubscriptionsUtilityLUD");
		String userName = "RXXAND";
        String baseUrl = null;
        String canonicalURI = null; // TODO parse from queryUrl
        String searchResponse = null;
        String queryString = null;
        String language = "en_GB";
        try {
            LudCSSRestClient ludCSSRestClient = new LudCSSRestClient();
            String typeOfDoc = "all";
            String hits = "50";
            String lastModified = "week";
            LOGGER.info("userName in LUD doget :"+userName);
            final String virtualPortalIdString = "ic";
        	baseUrl = PRESALES_SEARCH_URL;
        	canonicalURI = CANONICAL_PRESALES_URI;
        	final String types = "TRUCK,BUS,SERVICES,TYPE-APPROVAL";
        	for (final String type : Arrays.asList(types.split(","))) {
         	 
	        	 TreeMap<String, String> queryParameters = new TreeMap<String, String>();
		         queryParameters.put("q", "*");
		         queryParameters.put("search", "latest");
		         queryParameters.put("bodywork-language", language);
		         queryParameters.put("facet", "true");
		         queryParameters.put("sort", "last_modified_desc");
		         queryParameters.put("type", type.toLowerCase());
		         queryParameters.put("hits", hits);
		         queryParameters.put("last_modified", lastModified);
	         	if(userName != null){
	         		queryString = "q=*&search=latest&bodywork-language="+language+"&facet=true&sort=last_modified_desc&type="+type.toLowerCase()+"&hits="+hits+"&last_modified="+lastModified+"&xdsuser="+userName;
	         		queryParameters.put("xdsuser", userName);
	         	}
	         	LOGGER.info("queryString in getLatestUpdatedDocuments of NotificationSubscriptionsUtilityLUD : "+queryString);
	         	searchResponse = ludCSSRestClient.getLatestDocuments(queryString,queryParameters, baseUrl,canonicalURI);
	         	//LOGGER.info("searchResponse in getLatestUpdatedDocuments of NotificationSubscriptionsUtilityLUD : "+searchResponse);
	         	if(searchResponse != null && !searchResponse.isEmpty())
	         	{
	         		LOGGER.info("111111111::::::::::");
	         		JSONObject obj = new JSONObject(searchResponse);
	                int totalHits = obj.getJSONObject("stats").getInt("totalHits");
	         		
	         		LOGGER.info("totalHits::::::::::"+totalHits);
//	         		JSONParser parser = new JSONParser();
//	         		LOGGER.info("222222222222::::::::::");
//	         		JSONObject json = (JSONObject) parser.parse(searchResponse);
//	         		LOGGER.info("3333333333333::::::::::");
//	         		
//	         		if(json.get("totalHits") != null)
//	         		{
//	         			String totalHits = (String) json.get("totalHits"); 
//	         			LOGGER.info("totalHits::::::::::"+totalHits);
//	         		}
//	         		if(json.get("stats") != null)
//	         		{
//	         			String stats = (String) json.get("stats"); 
//	         			LOGGER.info("stats:::::::::::"+stats);
//	         		}
	         		LOGGER.info("NAAAAAAAAAAAAA");
	         	}
        	}
         	
        } catch (Exception e) {
        	LOGGER.info("Exception in doGet in getLatestUpdatedDocuments of NotificationSubscriptionsUtilityLUD");
        }
        LOGGER.info("Exiting from getLatestUpdatedDocuments of NotificationSubscriptionsUtilityLUD");
        return searchResponse;
	}
}
