package com.scania.aem.app.lud.utils;

import java.util.Dictionary;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyOption;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author rxxand
 * 
 *         Its a Scheduler to send periodic Emails based on the defined Business
 *         Rules.
 * 
 */
@Component(immediate = true, label = "Scania: Presales and Bodybuilder News Letters Scheduler", description = "Its a Scheduler to send emails for updated documents in Presales and Bodybuilder.", metatype = true)
@Property(name = "SERVICE_DESCRIPTION", label = "Service Description", value = "Scania Presales and Bodybuilder News Letters Scheduler")
public class NewsLettersScheduler {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(NewsLettersScheduler.class);

	@Property(name = "executionMode", label = "Execution Mode", options = {
			@PropertyOption(name = "Scheduled", value = "Scheduled"),
			@PropertyOption(name = "Immediate", value = "Immediate"),
			@PropertyOption(name = "Disabled", value = "Disabled") }, description = "Select the option here to decide when the service should run."
					+ " Disabled - will not run." + " Immediate - will run immediately."
					+ " Scheduled - will run as per the cron expression (Default).")
	private String executionMode = "Scheduled";

	@Property(name = "cronJobExpression", label = "Cron Job Expression", value = "0 0 0/12 1/1 * ? *", description = "Scheduler Cron Expression.")
	//private String cronJobExpression = "0 0 0/12 1/1 * ? *";
	private String cronJobExpression = "0 0 0/12 1/1 * ? *";

	@Property(name = "scheduler.runOn", value = "SINGLE", propertyPrivate = true)
	private String scheduledTaskName = "";

	@Reference
	private Scheduler scheduler; 

	@Reference
	private ResourceResolverFactory resolverFactory;

	private static final String WRITE_SERVICES = "writeservices";
	/**
	 * @param componentContext AEM Context 
	 * 
	 */
	@Activate
	protected void activate(final ComponentContext componentContext) {
		LOGGER.info("activate method started");
		LOGGER.info("Default Execution method " + executionMode);
		init(componentContext);
		LOGGER.info("Default Scheduled Task Name " + scheduledTaskName);
		LOGGER.info("Cron Job Expression " + cronJobExpression);
		LOGGER.debug("activate() method is executed successfully.");

	}

	/**
	 * @param componentContext
	 * 
	 */
	private void init(ComponentContext componentContext) {
		LOGGER.info("init method started");
		@SuppressWarnings("rawtypes")
		Dictionary props = componentContext.getProperties();
		
		LOGGER.info("after props..........");
		
		executionMode = (String) props.get("executionMode");
		cronJobExpression = (String) props.get("cronJobExpression");
		scheduledTaskName = (String) props.get("service.pid");
		LOGGER.info("executionMode:::::::::::"+executionMode);
		
		cronJobExpression = "* * * ? * *";
		
		LOGGER.info("cronJobExpression:::::::::::"+cronJobExpression);
		LOGGER.info("scheduledTaskName:::::::::::"+scheduledTaskName);
		if (StringUtils.isEmpty(scheduledTaskName)) {
			LOGGER.info("service.pid is unavailable");
			throw new IllegalStateException("service.pid is unavailable.");
		}
		AccessTokenScheduler task = new AccessTokenScheduler();
		if (StringUtils.equals(executionMode, "Disabled")) {
			LOGGER.info("under disabled execution mode");
			scheduler.unschedule(scheduledTaskName);
		} else {
			LOGGER.info("else of init called");
			if (StringUtils.equals(executionMode, "Scheduled")) {
				LOGGER.info("Excution mode is Scheduled");
				final ScheduleOptions schedulerOptions = scheduler.EXPR(cronJobExpression);
				schedulerOptions.canRunConcurrently(false);
				schedulerOptions.config(null);
				schedulerOptions.name(scheduledTaskName);
				scheduler.schedule(task, schedulerOptions);
			}
			if (StringUtils.equals(executionMode, "Immediate")) {
				LOGGER.info("Excution mode is Immediate");
				final ScheduleOptions schedulerOptions = scheduler.NOW();
				scheduler.schedule(task, schedulerOptions);
			}
		}
	}

	/**
	 * 
	 * Generate Access Token and save it under the path, /etc/designs/acs-base-app/accessToken.
	 */
	private class AccessTokenScheduler implements Runnable {
		@Override
		public void run() {
			LOGGER.info("-----Start of AccessTokenScheduler-----");
			ResourceResolver resolver = null;
			try {
				resolver = getResourceResolver(resolverFactory);  
				if(resolver!= null) {
					sendMail();
					//resolver.commit();
				}

			} catch (Exception e) {
				LOGGER.error("Exception in AccessTokenScheduler:" + e);
			}finally {
				resolver.close();
			}
			LOGGER.info("---End of  AccessTokenScheduler---");
		}    

		public ResourceResolver getResourceResolver(ResourceResolverFactory resolverFactory) throws LoginException {
			ResourceResolver resourceResolver = null;
			Map<String, Object> authenticationInfo = new ConcurrentHashMap<String, Object>();
			authenticationInfo.put(ResourceResolverFactory.SUBSERVICE, WRITE_SERVICES);
			resourceResolver = resolverFactory.getServiceResourceResolver(authenticationInfo);
			if (resourceResolver == null) {
				LOGGER.info("Resource Resolver failed to instantiate");
				return null;
			}
			return resourceResolver;
		}

	}

	/*
	 * Fetches the access token which is used as an Authorization for the calls to ACS
	 */
	private void sendMail()
    {
 	  LOGGER.info("sendMail method calling from NewsLettersScheduler...");
 	   
 	  String to = "rahul.lohagavkar@scania.com";//change accordingly  
	      String from = "rahul.lohagavkar@scania.com"; //change accordingly
	      String host = "localhost";//or IP address  
	     //Get the session object  
	      Properties properties = System.getProperties();  
	      properties.setProperty("mail.smtp.host", "mailhost.scania.com");  
	      properties.setProperty("mail.smtp.port", "xx");  
	      Session session = Session.getDefaultInstance(properties);  
	      
	      
	      //String contentForEmail = constructBBHEmailContent();
	      //String contentForEmail = emaiContent();
	      
	      LOGGER.info("Before calling constructPresalesEmailContent");
	      NotificationSubscriptionsUtilityLUD notLud = new NotificationSubscriptionsUtilityLUD(); 
	      String contentForEmail = notLud.constructPresalesEmailContent();
	      LOGGER.info("after calling constructPresalesEmailContent :"+contentForEmail);
	      
	  //compose the message  
	      try{  
	         MimeMessage message = new MimeMessage(session);  
	         message.setFrom(new InternetAddress(from));  
	         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	         
	         message.setSubject("Test Email");  
	         message.setContent(contentForEmail, "text/html; charset=utf-8");
	         // Send message  
	         Transport.send(message);  
	         
	        LOGGER.info("sendMail method ending from NewsLettersScheduler...");
	  
	      }catch (Exception mex) {mex.printStackTrace();}  
    }
	 public static String constructBBHEmailContent() {
	        final StringBuffer contentBuilder = new StringBuffer();
	        try {
				contentBuilder.append("<!DOCTYPE html><html><table  cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; background-color:white;'>" + "<tr>"
				        + "<td align='left' bgcolor='red' style='padding: 0px 10px 10px 13px;'><span style='font-size:12px; color: #555; font-family: \"OpenSans\",Arial,sans-serif;'>This is sample email content through HTML code(sample testing)</span></td>"
				        + "</tr>" + "</table></html>");
	        } catch (final Exception ex) {
	        }
	        return contentBuilder.toString();
	    }
	 
	 public String emaiContent()
	 {
		 final StringBuffer contentBuilder = new StringBuffer();
		 String header = "<html xmlns='http://www.w3.org/1999/xhtml' style='background-color:#f5f5f5;'>"
					+"<head>"
					    +"<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>"
					   +" <meta name='viewport' content='width=device-width, initial-scale=1.0'>"
					   +" <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
					+"</head>"
					+"<body style='margin: 0; padding: 0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;'>"
					   +" <table width='100%'>"
					      +"  <table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8; background-color:#fff;'>"
					        +"    <tr>"
					             +"   <td align='left' width='90%' bgcolor='#fff' style='padding: 14px; border-top: 2px solid #ceb888;'>"
					              +"      <h1 style='-moder-bottom-width: 0; color: #666; font-family: 'Open Sans', Arial, sans-serif; font-size: 24px; font-weight: 600; line-height: 1.1; padding-bottom: 0; margin: 15px 0 3px;'>Document news from Presales.scania.com</h1> </td>"
					              +"  <td align='right' width='10%' bgcolor='#fff' style='padding: 14px; border-top: 2px solid #ceb888;'> <img src='https://static.scania.com/resources/logotype/scania/scania-symbol.png' width='36' height='36' style='display: block;'> </td>"
					
					           +" </tr>"
					       +" </table>";
 contentBuilder.append(header);
 
// final BufferedReader inFooter = new BufferedReader(
//         new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream("/jsp/latest-document-portlet/html/footer_Presales.html"), Charset.forName("UTF-8")));
 
 String footer = "<table align='center' cellpadding='0' cellspacing='0' width='600' style='border-collapse: collapse;  border-bottom: 2px solid #ceb888; border-right:  1px solid #e8e8e8; border-left:  1px solid #e8e8e8;  background-color:#fff;'>"
	                +"<tr>"
				                +"<td align='left' bgcolor='white' width='30%' style='padding: 0 14px; font-family: Arial, Helvetica, Open Sans, sans-serif; font-size: 10px;'>"
				                   +" <br style='box-sizing: border-box; padding-left: 10px;'> Scania CV AB"
				                    +"<br style='box-sizing: border-box; padding-left: 10px;'> SE-151 87 Södertälje, Sweden"
				                   +" <br style='box-sizing: border-box; padding-left: 10px;'> www.scania.com </td>"
				               +" <td align='center' bgcolor='white' width='40%' style='padding:14px 0; font-family: Arial, Helvetica, Open Sans, sans-serif; font-size: 10px;'>"
				                   +" <br style='box-sizing: border-box;'> Tel: &#43;46-8-55 38 10 00 Fax: &#43;46-8-55 38 10 37 "
				                   +" <br style='box-sizing: border-box;'> Registered in Sweden: No. 556184-8564"
				                   +" <br style='box-sizing: border-box;'> Registered Office: Södertälje, Sweden </td>"
				               +" <td align='right' bgcolor='white' width='30%' style='padding: 0 14px;'> <img src='https://static.scania.com/resources/logotype/scania/scania-wordmark.png' alt='' width='150' height='24' style='border-style: none; float: right;'> </td>"
				           +" </tr>"
				       +" </table>"
				    +"</table>"
				+"</body>"
				+"</html>";

 contentBuilder.append(footer);
 
 return contentBuilder.toString();
	 }
}


