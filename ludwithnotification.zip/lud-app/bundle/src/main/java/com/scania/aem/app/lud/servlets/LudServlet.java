package com.scania.aem.app.lud.servlets;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scania.aem.app.lud.utils.LudCSSRestClient;

/**
 * @author rrah52
 * This servlet will validate the complete sign in process for Quiz Component.
 *
 */

@Component(immediate = false, metatype = true)
@Service(value = javax.servlet.Servlet.class)
@Properties({ @Property(name = "sling.servlet.methods", value = { "GET", "POST" }),
	@Property(name = "sling.servlet.extensions", value = { "json", "html" }),
	@Property(name = "Serviceaccount", value = { "servicewpsadmin" }),
	@Property(name = "sling.servlet.paths", value = { "/bin/lud.json" }) })

public class LudServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 366299376855436190L;
	private static final Logger LOGGER = LoggerFactory.getLogger(LudServlet.class);
    private static final String READ_SERVICES = "readservices";
    
    
    private static final String TBB_SEARCH_URL_FOR_LOGGIN_USER = "https://search.reflex.prod.aws.scania.com/v0/authentication/css/apps/rest/apps/bodybuilder-portal/searchers/bodybuilder-portal?";
    private static final String CANONICAL_TBB_URI = "/v0/authentication/css/apps/rest/apps/bodybuilder-portal/searchers/bodybuilder-portal"; // TODO parse from queryUrl
    private static final String CANONICAL_PRESALES_URI = "/v0/authentication/css/apps/rest/apps/presales-portal/searchers/presales-portal"; // TODO parse from queryUrl
    private static final String PRESALES_SEARCH_URL = "https://search.reflex.prod.aws.scania.com/v0/authentication/css/apps/rest/apps/presales-portal/searchers/presales-portal?";
    
    
    @Reference
    private ResourceResolverFactory resolverFactory;
   
    @Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {

	}
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		
		
		LOGGER.info("Entered into LUD servresourse");
        try {
            String userName = null;
            String baseUrl = null;
            String canonicalURI = null; // TODO parse from queryUrl
            String searchResponse = null;
            String queryString = null;
            String language = "en_GB";
            
            LudCSSRestClient ludCSSRestClient = new LudCSSRestClient();
            String type = "all";
            String hits = "20";
            String lastModified = "week";
            userName = getUserID();
            LOGGER.info("userName in LUD doget :"+userName);
            final String virtualPortalIdString = "ic";
//            if (BBH_PORTAL_NAME.equalsIgnoreCase(portletPreferences.getValue(IDENT, BBH_PORTAL_NAME))) {
//            	baseUrl = TBB_SEARCH_URL_FOR_LOGGIN_USER;
//            	canonicalURI = CANONICAL_TBB_URI;
//            } else if (PRESALES_PORTAL_NAME.equalsIgnoreCase(portletPreferences.getValue(IDENT, PRESALES_PORTAL_NAME))) {
//            	//baseUrl = this.searchProperties.get(virtualPortalIdString + CLOUD_BASE_URL);
//            	baseUrl = PRESALES_SEARCH_URL;
//            	canonicalURI = CANONICAL_PRESALES_URI;
//            }
        	baseUrl = PRESALES_SEARCH_URL;
        	canonicalURI = CANONICAL_PRESALES_URI;
         	TreeMap<String, String> queryParameters = new TreeMap<String, String>();
	         queryParameters.put("q", "*");
	         queryParameters.put("search", "latest");
	         queryParameters.put("bodywork-language", language);
	         queryParameters.put("facet", "true");
	         queryParameters.put("sort", "last_modified_desc");
	         queryParameters.put("type", type);
	         queryParameters.put("hits", hits);
	         queryParameters.put("last_modified", lastModified);
         	
         	if(userName != null){
         		queryString = "q=*&search=latest&bodywork-language="+language+"&facet=true&sort=last_modified_desc&type="+type+"&hits="+hits+"&last_modified="+lastModified+"&xdsuser="+userName;
         		queryParameters.put("xdsuser", userName);
         	}else
         	{
         		queryString = "q=*&search=latest&bodywork-language="+language+"&facet=true&sort=last_modified_desc&type="+type+"&hits="+hits+"&last_modified="+lastModified;	
         	}
         	
         	LOGGER.info("queryString for LUD: "+queryString);
         	
         	searchResponse = ludCSSRestClient.getLatestDocuments(queryString,queryParameters, baseUrl,canonicalURI);
         	LOGGER.info("searchResponse from LUD: "+searchResponse);
//         	
//         	if(searchResponse != null){
//	         	byte pText[] = searchResponse.getBytes("ISO_8859_1");
//	         	searchResponse = new String(pText, "UTF_8");
//         	}
         	LOGGER.info("searchResponse for LUD : "+searchResponse);
            response.setCharacterEncoding("UTF-8");
    		response.getWriter().write(searchResponse);
        } catch (Exception e) {
        	LOGGER.info("Exception in doGet of LUD servlet");
        }
		//response.getWriter().write("hello");
        LOGGER.info("Exit from LUD servresourse");
	}

	  public String getUserID() {
		  ResourceResolver adminResolver = null;
		  String userId = null;
		  try
		  {
		    adminResolver = resolverFactory.getThreadResourceResolver();
		    Session session = adminResolver.adaptTo(Session.class);
		    if(session.getUserID() != null && !session.getUserID().isEmpty())
		    {
		    	userId = session.getUserID().toUpperCase();
		    }
		    return userId;
		  }
		  catch (Exception e)
		  { 
		      LOGGER.trace("Error",e); 
		      return e.getMessage();
		  }
    }
	public ResourceResolver getResourceResolver(ResourceResolverFactory resolverFactory) throws LoginException {
        ResourceResolver resourceResolver = null;
        Map<String, Object> authenticationInfo = new ConcurrentHashMap<String, Object>();
        authenticationInfo.put(ResourceResolverFactory.SUBSERVICE, READ_SERVICES);
        resourceResolver = resolverFactory.getServiceResourceResolver(authenticationInfo);
        if (resourceResolver == null) {
            LOGGER.error("Resource Resolver failed to instantiate for lud application");
        }
        return resourceResolver;
    }


}
