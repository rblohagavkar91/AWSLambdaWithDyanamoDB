@Version("1.0.0")
package com.scania.aem.app.lud;

import aQute.bnd.annotation.Version;