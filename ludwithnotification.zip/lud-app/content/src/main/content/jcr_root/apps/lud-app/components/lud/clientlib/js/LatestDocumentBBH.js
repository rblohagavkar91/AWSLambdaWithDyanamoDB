dojo.require("dojox.grid.EnhancedGrid");
dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojox/grid/enhanced/plugins/Pagination");
dojo.require("dojox/widget/Calendar");
dojo.require("dojo.on");
dojo.ready(function() {
	
    function logger(event, data, status) {
        if (data != "no results") {
            dojo.xhrGet({
                url : '/aps-rest-logger/v1/ui/log?appname=tbb&status= ' + data + '&level=INFO&event= ' + event + '&timezone=CET&errMsg=' + status
            });
        } else {
            var  pageId = '';
            var browserInfo = 'Unknown';
            if (getBrowser() != null && getBrowser() != undefined){
                browserInfo = getBrowser().name + getBrowser().version;
            }
            if (document.getElementById('asa.page') != null){
                pageId = document.getElementById('asa.page').innerText.trim();
            }
            if (userId === 'null'){
                userId = 'Anonymous';
            }
            status = status + ',User agent: ' + browserInfo +  ',Browser locale:' + navigator.language + ',Page Id: ' +pageId + ',Browser url: ' + window.location.href;
            dojo.xhrGet({
                url : '/aps-rest-logger/v1/ui/log?appname=tbb&status= ' + data + '&level=ERROR&event= ' + event + '&uid= '
                        + userId + '&timezone=CET&language= ' + selectedLanguage + '&errMsg=' + status
            });
        }
    }
    dojo.xhrGet({
        url : resourceUrlLatest,
        load : function(response, ioargs) {
        	var data = JSON.parse(response);
        	data = dojo.fromJson(data);
            var dataObject = {
                identifier : 'id',
                items : []
            };
            for (var i = 0, l = data.documentList.documents.length; i < l; i++) {
                dataObject.items.push(dojo.mixin({
                    id : i + 1
                }, data.documentList.documents[i % l]));
            }
            var store = new dojo.data.ItemFileWriteStore({
                data : dataObject
            });
            function createLink(data, rowindex) {
                var link = this.grid.getItem(rowindex).file_url ? this.grid.getItem(rowindex).file_url[0].substring(0, this.grid.getItem(rowindex).file_url[0].indexOf("?")) : this.grid
                        .getItem(rowindex).url;
                var name = this.grid.getItem(rowindex).alternative_title && this.grid.getItem(rowindex).alternative_title[0] && !(this.grid.getItem(rowindex).alternative_title[0] == "") ? this.grid
                        .getItem(rowindex).alternative_title[0] : this.grid.getItem(rowindex).title;
                var description = this.grid.getItem(rowindex).description ? this.grid.getItem(rowindex).description : "";
                return ("<a title='" + description + "' href='" + link + "' target='_blank'>" + name + "</a>");
            }
            function iconFormatter(data, rowindex) {
                if (data == "PGRS") {
                    return ("<i title='New Truck Generation' class='P-G-R-S-series'/>");
                } else
                    if (data == "PGRT") {
                        return ("<i title='PGRT' class='P-G-R-T-series'/>");
                    } else
                    	{
                    		if(!isNaN(data)){
//		                        if (data && data.contains("PGRS") && data.contains("PGRT")) {
//		                            return ("<i title='New Truck Generation, PGRT' class='P-G-R-T-series'/>");
//		                        } else {
//		                            return ("<i title='' class='P-G-R-series'/>");
//		                        }
                    			
                    			if (data && data.includes("PGRS") && data.includes("PGRT")) {
		                            return ("<i title='New Truck Generation, PGRT' class='P-G-R-T-series'/>");
		                        } else {
		                            return ("<i title='' class='P-G-R-series'/>");
		                        }
                    			
                    		}else
                        	{
                        		return ("<i title='' class='P-G-R-series'/>");
                        	}
                    	}
            }
            function openWindow(url) {
                if (window.innerWidth <= 640) {
                    var a = document.createElement('a');
                    a.setAttribute("href", url);
                    a.setAttribute("target", "_blank");
                    var dispatch = document.createEvent("HTMLEvents");
                    dispatch.initEvent("click", true, true);
                    a.dispatchEvent(dispatch);
                } else {
                    var width = window.innerWidth * 0.66;
                    var height = width * window.innerHeight / window.innerWidth;
                    window.open(url, 'newwindow', 'width=' + width + ', height=' + height + ', top=' + ((window.innerHeight - height) / 2) + ', left=' + ((window.innerWidth - width) / 2));
                }
                return false;
            }
            var layout = [{
                cells : [{
                    field : "generation",
                    name : "",
                    datatype : "string",
                    formatter : iconFormatter,
                    tooltip : "type of document",
                    width : '3',
                    cellStyles : "border: none;",
                    headerStyles : "display: none;"
                }, {
                    field : "alternative_title",
                    name : "",
                    datatype : "string",
                    formatter : createLink,
                    width : '25',
                    cellStyles : "border: none;",
                    headerStyles : "display: none;"
                }]
            }];
            var grid = new dojox.grid.EnhancedGrid({
                id : 'grid',
                store : store,
                structure : layout,
                autoHeight : 'true',
                style : 'width: auto;',
                noDataMessage : "No documents available",
                loadingMessage : 'Documents loading',
                errorMessage : 'Error loading documents',
                plugins : {
                    pagination : {
                        pageSizes : ["25", "50"],
                        description : true,// '5',
                        itemTitle : '',
                        maxPageStep : 4,
                        position : "bottom",
                        defaultPageSize : parseInt(pageSize)
                    }
                }
            }, document.createElement('div').style.setProperty("width", "25"));
            dojo.byId("gridDiv").appendChild(grid.domNode);
            dojo.connect(grid, "_onFetchComplete", function() {
                if (toggleFocus.toUpperCase() === "FALSE") {
                    document.getElementById("search-text").focus();
                }
            });
            grid.startup();
            logger("latest updated document query", ioargs.xhr.statusText, ioargs.xhr.status);
        },
        error : function(error, ioargs) {
            logger("latest updated document error code " + ioargs.xhr.status, "no results", ioargs.xhr.statusText);
        }
    });
});
function getBrowser() {
    var userAgent=navigator.userAgent,tem,M=userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || []; 
    if(/trident/i.test(M[1])){
        tem=/\brv[ :]+(\d+)/g.exec(userAgent) || []; 
        return {name:'IE',version:(tem[1]||'')};
        }   
    if(M[1]==='Chrome'){
        tem=userAgent.match(/\bOPR|Edge\/(\d+)/);
        if(tem!=null)   {return {name:'Opera', version:tem[1]};}
        }   
    M=M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
    if((tem=userAgent.match(/version\/(\d+)/i))!=null) {M.splice(1,1,tem[1]);}
    return {
      name: M[0],
      version: M[1]
    };
 }