dojo.require("dojox.grid.EnhancedGrid");
dojo.require("dojo.data.ItemFileWriteStore");
dojo.require("dojox/grid/enhanced/plugins/Filter");
dojo.require("dojox/grid/enhanced/plugins/exporter/CSVWriter");
dojo.require("dojox/grid/enhanced/plugins/Printer");
dojo.require("dojox/grid/enhanced/plugins/Cookie");
dojo.require("dojox/grid/enhanced/plugins/IndirectSelection");
dojo.require("dojox/grid/enhanced/plugins/NestedSorting");
dojo.require("dojox/grid/enhanced/plugins/Selector");
dojo.require("dojox/grid/enhanced/plugins/Menu");
dojo.require("dojox/grid/enhanced/plugins/DnD");
dojo.require("dojox/grid/enhanced/plugins/Search");
dojo.require("dojox/grid/enhanced/plugins/CellMerge");
dojo.require("dojox/grid/enhanced/plugins/Pagination");
dojo.require("dojox/grid/enhanced/plugins/Rearrange");
dojo.ready(function() {
  var data_list = null;
  dojo.xhrGet({
	  url: resourceUrlLatest,
	  load: function(data){
		  data_list = data;
	  },
	  error: function(data){
	  }
	 });
  var data = {
    identifier: 'id',
    items: data_list
  };
  var store = new dojo.data.ItemFileWriteStore({
    data: data
  });
  function createLink(data, rowindex){
    return ("<a href=" + this.grid.getItem(rowindex).preferred_link + ">"+data+"</a>");
}
function iconFormatter(data, rowindex){
    return ("<i class='icon-"+data +"'/>");
}
  var layout = 
     [{
      defaultCell: {
        editable: false,
        autoComplete: true,
        type: dojox.grid.cells._Widget
      },
      cells: [

        {
          field: "object_type",
          name: "Type",
          datatype: "string",
          width: "auto",
          formatter: iconFormatter
        }, {
          field: "preferred_name",
          name: "Name",
          datatype: "string",
          width: "auto",
          formatter: createLink
        }, {
          field: "context_maturity_model_s",
          name: "Source",
          datatype: "string",
          width: "auto"
        }, {
          field: "object_maingroup_s",
          name: "Group",
          datatype: "string",
          width: "auto"
        }, {
          field: "object_model_s",
          name: "Model",
          datatype: "string",
          width: "auto"
        }, {
          field: "content",
          name: "Description",
          datatype: "string",
          width: "auto"
        }
      ]
    }];
  var grid = new dojox.grid.EnhancedGrid({
      id: 'grid',
      store: store,
      structure: layout,
      rowSelector: '20px',
      autoHeight: 'true',
      plugins: {
        indirectSelection: {
          headerSelector: true
        },
        cookie: true,
        nestedSorting: true,
        menus: {
          headerMenu: "headerMenu",
          rowMenu: "rowMenu",
          cellMenu: "cellMenu",
          selectedRegionMenu: "selectedRegionMenu"
        },
        exporter: true,
        printer: true,
        filter: {
          closeFilterbarButton: true
        },
        rearrange: true,
        selector: true,
        dnd: true,
        cellMerge: {
          "mergedCells": [{
            row: "3",
            start: 1,
            end: 10,
            major: 3
          }]
        },
        search: true,
        pagination: {
          pageSizes: ["10", "25", "50", "100"],
          description: true,
          sizeSwitch: true,
          pageStepper: true,
          gotoButton: true,
          maxPageStep: 4,
          position: "bottom"
        }
      }
    },
    document.createElement('div'));
  dojo.byId("gridDiv").appendChild(grid.domNode);
  grid.startup();
});